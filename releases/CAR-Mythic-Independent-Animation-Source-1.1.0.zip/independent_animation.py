"""Build isolated mythic core, eye and wing autoplay layers.

The gun body remains rigid on def_c_base.  Only meshes using the eye and
feather material families are rebound, so ordinary CAR weapon animations do
not move the mythic decoration roots.
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parent
VIEW = ROOT / "source" / "view"
WORLD = ROOT / "source" / "world"
BEGIN = "// CODEX_INDEPENDENT_MYTHIC_ANIMATION_BEGIN"
END = "// CODEX_INDEPENDENT_MYTHIC_ANIMATION_END"


def smd_nodes(lines: list[str]) -> dict[int, str]:
    start = lines.index("nodes")
    end = lines.index("end", start)
    result = {}
    for line in lines[start + 1 : end]:
        index, rest = line.split(" ", 1)
        result[int(index)] = rest.split('"')[1]
    return result


def rebind_material_groups(path: Path) -> dict:
    lines = path.read_text(encoding="utf-8").splitlines()
    nodes = smd_nodes(lines)
    ids = {name: index for index, name in nodes.items()}
    required = ("def_c_base", "def_eye_body", "def_wing_upper_arm_l_1", "def_wing_upper_arm_r_1")
    missing = [name for name in required if name not in ids]
    if missing:
        raise RuntimeError(f"{path}: missing bones {missing}")
    tri = lines.index("triangles")
    out = lines[: tri + 1]
    cursor = tri + 1
    counts = {"body": 0, "eye": 0, "wingLeft": 0, "wingRight": 0}
    while lines[cursor] != "end":
        material = lines[cursor]
        out.append(material)
        cursor += 1
        lowered = material.lower().replace("/", "\\")
        for _ in range(3):
            fields = lines[cursor].split()
            x = float(fields[1])
            if "\\eye_" in lowered or "mythic_glow\\eye" in lowered:
                target, key = ids["def_eye_body"], "eye"
            elif "\\feather_" in lowered:
                if x >= 0:
                    target, key = ids["def_wing_upper_arm_l_1"], "wingLeft"
                else:
                    target, key = ids["def_wing_upper_arm_r_1"], "wingRight"
            else:
                target, key = ids["def_c_base"], "body"
            # Retain position, normal and UV; replace the complete weight list.
            out.append(" ".join([str(target), *fields[1:9], "1", str(target), "1.00000000"]))
            counts[key] += 1
            cursor += 1
    path.write_text("\n".join(out + ["end"]) + "\n", encoding="utf-8")
    counts["file"] = str(path)
    return counts


def split_motion(source: Path, selections: dict[str, set[str]]) -> dict[str, Path]:
    lines = source.read_text(encoding="utf-8").splitlines()
    nodes = smd_nodes(lines)
    ids = {name: index for index, name in nodes.items()}
    skeleton = lines.index("skeleton")
    end = lines.index("end", skeleton)
    prefix = lines[: skeleton + 1]
    outputs = {}
    for stem, names in selections.items():
        wanted = {ids[name] for name in names}
        body = []
        for line in lines[skeleton + 1 : end]:
            if line.startswith("time "):
                body.append(line)
            elif int(line.split()[0]) in wanted:
                body.append(line)
        destination = source.with_name(stem + ".smd")
        destination.write_text("\n".join(prefix + body + ["end"]) + "\n", encoding="utf-8")
        outputs[stem] = destination
    return outputs


def weightlist(name: str, bones: list[str], active: set[str]) -> str:
    rows = [f'$weightlist "{name}" {{']
    rows.extend(f' "{bone}" {1 if bone in active else 0}' for bone in bones)
    rows.append("}")
    return "\n".join(rows)


def append_layers(qc: Path, motion: Path, view: bool) -> list[str]:
    text = qc.read_text(encoding="utf-8")
    if BEGIN in text:
        text = text[: text.index(BEGIN)] + text[text.index(END) + len(END) :]
    nodes = list(smd_nodes(motion.read_text(encoding="utf-8").splitlines()).values())
    layers = [
        ("mythic_motion", "mythic_core_motion", "mythic_core_only", {"def_core_orb"}),
    ]
    if view:
        layers += [
            ("mythic_eye_motion", "mythic_eye_motion", "mythic_eye_only", {"def_eye_body"}),
            (
                "mythic_wing_motion",
                "mythic_wing_motion",
                "mythic_wings_only",
                {"def_wing_upper_arm_l_1", "def_wing_upper_arm_r_1"},
            ),
        ]
    block = [BEGIN]
    for sequence, smd, weights, active in layers:
        block.append(weightlist(weights, nodes, active))
        block.append(
            f'$sequence "{sequence}" {{ "{smd}.smd" fps 30 loop delta autoplay weightlist "{weights}" }}'
        )
    block.append(END)
    qc.write_text(text.rstrip() + "\n\n" + "\n".join(block) + "\n", encoding="utf-8")
    return [item[0] for item in layers]


def main() -> None:
    backup = ROOT / "backups" / "before-independent-animation-1.1.0"
    if not backup.exists():
        shutil.copytree(ROOT / "source", backup / "source")
    geometry = [
        rebind_material_groups(VIEW / "mythic_base.smd"),
        rebind_material_groups(VIEW / "mythic_evolved.smd"),
    ]
    split_motion(
        VIEW / "mythic_motion.smd",
        {
            "mythic_core_motion": {"def_core_orb"},
            "mythic_eye_motion": {"def_eye_body"},
            "mythic_wing_motion": {"def_wing_upper_arm_l_1", "def_wing_upper_arm_r_1"},
        },
    )
    split_motion(WORLD / "mythic_motion.smd", {"mythic_core_motion": {"def_core_orb"}})
    view_layers = append_layers(VIEW / "ptpov_car101.qc", VIEW / "mythic_motion.smd", True)
    world_layers = append_layers(WORLD / "w_car_richmahogany.qc", WORLD / "mythic_motion.smd", False)
    report = {
        "version": "1.1.0",
        "gameTested": False,
        "bodyAnimated": False,
        "viewLayers": view_layers,
        "worldLayers": world_layers,
        "geometryBindings": geometry,
        "coreCycleDegrees": 360,
        "wingRootAmplitudeRadians": 0.069771,
        "eyeAmplitudeRadians": 0.017443,
    }
    (ROOT / "independent-animation-audit.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
