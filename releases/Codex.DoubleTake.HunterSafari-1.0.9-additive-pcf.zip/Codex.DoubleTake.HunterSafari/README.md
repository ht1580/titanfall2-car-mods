双重击 Hunter Safari RT01 贴图修正版。修正重复 sRGB 编码、过强自发光及流式加载结构；未覆盖武器脚本。
