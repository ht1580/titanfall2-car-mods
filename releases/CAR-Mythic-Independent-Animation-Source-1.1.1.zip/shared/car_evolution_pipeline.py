"""Shared, repeatable v1.0.1 evolution switch and release audit (no game launch)."""
import hashlib,json,re,shutil,struct,zipfile
from pathlib import Path

VERSION='1.0.1'
RELEASE=Path('D:/TitanfallMods')
PATCH='''WeaponData
{
    Mods
    {
        iron_sights
        {
            "viewmodel_offset_ads" "0 0 0.65"
        }
        pro_screen
        {
            "ui8_enable" "0"
        }
    }
}
'''

def cstr(d,p):return d[p:d.index(0,p)].decode()
def blocks(text,command):
    pattern=re.compile(r'\$'+command+r'\s+"([^"]+)"[^\n{]*\s*\{')
    for match in pattern.finditer(text):
        depth=1;end=match.end()
        while depth:
            if text[end]=='{':depth+=1
            if text[end]=='}':depth-=1
            end+=1
        yield match.group(1),match.start(),end,text[match.end():end-1]

def backup(project):
    target=project/'backups/before-switch-1.0.1'
    if not target.exists():
        target.mkdir(parents=True)
        shutil.copytree(project/'source',target/'source')
        folder='CAR.Mythic.Allfather' if project.name=='car_mythic' else 'CAR.OutlandsAnnihilator'
        shutil.copytree(RELEASE/folder,target/'release')

def prepare(project):
    from work.car_stability import policy,prepare_static
    config=policy(project)
    # Independently authored autoplay layers are already isolated from the
    # weapon sequences.  Do not reinsert the old per-sequence addlayer graph.
    if config and config.get('independentAnimation'):
        return
    if config and config.get('rigidDecoration'):
        switch=json.loads((project/'switch-policy.json').read_text());switch['motion']=None;switch['rigidDecoration']=True
        (project/'switch-policy.json').write_text(json.dumps(switch,indent=2))
        return
    if config and config['staticCounter']:
        prepare_static(project)
        return
    backup(project)
    mythic=project.name=='car_mythic';motion='mythic_motion' if mythic else 'outlands_spin'
    for variant in ['view','world']:
        folder=project/'source'/variant;qc=next(folder.glob('*.qc'));text=qc.read_text()
        if mythic:
            base=folder/'mythic_base.smd';evolved=folder/'mythic_evolved.smd'
        else:
            base=folder/('v_car101.smd' if variant=='view' else 'car_lgnd_v21_retromodern_w_body_0_lod0.smd')
            body=folder/('v_car101_evolved.smd' if variant=='view' else 'w_car_evolved.smd')
            effect=folder/('v_proscreen.smd' if variant=='view' else 'stock_w_proscreen.smd')
            evolved=folder/'evolution_full.smd'
            # The ring is part of evolved geometry, never controlled by an optic flag.
            a=body.read_text().splitlines();b=effect.read_text().splitlines()
            evolved.write_text('\n'.join(b[:b.index('triangles')+1]+a[a.index('triangles')+1:-1]+b[b.index('triangles')+1:])+'\n')
        edits=[]
        for name,start,end,content in blocks(text,'bodygroup'):
            if name in ['car101_body','car101']:
                edits.append((start,end,f'$bodygroup "{name}"\n{{\n blank\n}}'))
            elif name=='proscreen':
                edits.append((start,end,f'$bodygroup "proscreen"\n{{\n studio "{base.name}"\n studio "{evolved.name}"\n}}'))
        assert len(edits)==2
        for start,end,value in reversed(edits):text=text[:start]+value+text[end:]
        # Do not apply the same motion again inside an already layered helper.
        text=re.sub(r'\s*addlayer\s+"'+motion+r'"','',text)
        children=set(re.findall(r'\b(?:addlayer|blendlayer)\s+"([^"]+)"',text))
        edits=[]
        for name,start,end,content in blocks(text,'sequence'):
            if name not in children|{motion,'ref'} and not (mythic and re.search(r'\bautoplay\b',content)):
                edits.append((end-1,'\n addlayer "'+motion+'"\n'))
        for at,value in reversed(edits):text=text[:at]+value+text[at:]
        if mythic:
            # A one-frame parent can supply NaN cycle timing to an added layer.
            # Run the procedural detail motion on its own clock instead.
            text=re.sub(r'\s*addlayer\s+"mythic_motion"','',text)
            for name,a,b,content in blocks(text,'sequence'):
                if name=='mythic_motion' and not re.search(r'\bautoplay\b',content):
                    text=text[:b-1]+' autoplay '+text[b-1:]
                    break
        qc.write_text(text)
    (project/'switch-policy.json').write_text(json.dumps({'version':VERSION,'stockName':'bodygroup5_name','bodygroup':'proscreen','stockFlag':'bodygroup5_set','disabled':0,'enabled':1,'ui':'ui8_enable','uiValue':0,'counterGeometry':False,'motion':motion},indent=2))

def inspect(path,mythic,static=False,rigid=False):
    d=path.read_bytes();assert d[:4]==b'IDST' and struct.unpack_from('<i',d,4)[0]==53
    assert struct.unpack_from('<i',d,80)[0]==len(d)
    nb,bo=struct.unpack_from('<2i',d,160);bones=[cstr(d,bo+i*244+struct.unpack_from('<i',d,bo+i*244)[0]) for i in range(nb)]
    n,o=struct.unpack_from('<2i',d,236);groups=[]
    for i in range(n):
        at=o+i*16;name,num,base,models=struct.unpack_from('<4i',d,at)
        groups.append({'name':cstr(d,at+name),'models':num,'base':base})
    view=path.name=='ptpov_car101.mdl'
    assert n==(7 if view else 6)
    assert groups[0]['models']==1 and groups[4]=={'name':'proscreen','models':2,'base':8}
    # Original factors retained: optics 1/2/4, proscreen 8, irons 16, magazine 32.
    assert [g['base'] for g in groups]==([1,1,2,4,8,16,32] if view else [1,1,2,4,8,16])
    nt,to=struct.unpack_from('<2i',d,208);materials=[cstr(d,to+i*44+struct.unpack_from('<i',d,to+i*44)[0]) for i in range(nt)]
    if not static:assert not any('pro_screen' in s for s in materials),materials
    refs,families,skin=struct.unpack_from('<3i',d,224);assert families==9
    table=struct.unpack_from('<'+'h'*(refs*families),d,skin);assert all(0<=i<nt for i in table)
    if mythic:
        for index,color in [(1,'rt01'),(6,'rt02'),(8,'rt03')]:
            row=[materials[i] for i in table[index*refs:(index+1)*refs]]
            assert all(any(k+'_'+stage+'_'+color in s for s in row) for stage in ['base','evolved'] for k in ['eye','feather','main'])
    ns,so=struct.unpack_from('<2i',d,192);labels=[cstr(d,so+i*232+struct.unpack_from('<i',d,so+i*232+4)[0]) for i in range(ns)]
    motion=labels.index('mythic_motion' if mythic else 'outlands_spin') if not (static or rigid) else -1;edges={}
    if rigid:assert 'mythic_motion' not in labels and not any('mythic_inspect' in s for s in labels)
    if static:assert 'outlands_spin' not in labels
    for i in range(ns):
        q=so+i*232;num,off=struct.unpack_from('<2i',d,q+148);edges[i]=[]
        for j in range(num):
            target=struct.unpack_from('<h',d,q+off+j*24)[0];assert 0<=target<ns;edges[i].append(target)
    def hits(i,seen):
        assert i not in seen,'Cycle in animation layers'
        return (1 if i==motion else 0)+sum(hits(k,seen|{i}) for k in edges[i])
    assert max(hits(i,set()) for i in range(ns))==(0 if (static or rigid) else 1)
    nr,ro=struct.unpack_from('<2i',d,296);assert nr==(6 if view else 0);rui=[]
    for i in range(nr):
        q=ro+i*8;m=q+struct.unpack_from('<i',d,q+4)[0];np,nv,nf,pi,vi,vmi,fi=struct.unpack_from('<7i',d,m)
        assert m%16==0 and m+fi+nf*32<=len(d)
        parents=[struct.unpack_from('<h',d,m+pi+j*2)[0] for j in range(np)];assert all(0<=p<nb for p in parents)
        rui.append({'name':cstr(d,m+32),'parents':[bones[p] for p in parents]})
    assert struct.unpack_from('<i',d,340)[0]==0
    return {'bones':nb,'bodygroups':groups,'rui':rui,'materials':materials,'skinFamilies':families,'motionLayers':sum(motion in v for v in edges.values()),'maxMotionApplications':0 if (static or rigid) else 1,'sha256':hashlib.sha256(d).hexdigest()}

def package(project,result):
    from work.car_stability import policy
    config=policy(project);static=bool(config and config['staticCounter'])
    VERSION='1.0.2' if (project/'inspect-authoring.json').exists() else '1.0.1'
    if config:VERSION=config['version']
    mythic=project.name=='car_mythic';folder='CAR.Mythic.Allfather' if mythic else 'CAR.OutlandsAnnihilator';pak='car_mythic' if mythic else 'car_outlands'
    cache=project/'compiled';cache.mkdir(exist_ok=True)
    dst=RELEASE/folder;mp=dst/'mod/models/weapons/car101';mp.mkdir(parents=True,exist_ok=True)
    report={'version':VERSION,'gameTested':False,'switch':json.loads((project/'switch-policy.json').read_text()),'models':{}}
    report['switch']['version']=VERSION
    if (project/'inspect-authoring.json').exists():report['inspect']=json.loads((project/'inspect-authoring.json').read_text())
    for variant,name in [('view','ptpov_car101'),('world','w_car101')]:
        d=bytearray(Path(result[variant]).read_bytes());struct.pack_into('<i',d,80,len(d))
        cached=cache/(name+'.mdl');cached.write_bytes(d)
        report['models'][variant]=inspect(cached,mythic,static,bool(config and config.get('rigidDecoration')))
        shutil.copy2(cached,mp/(name+'.mdl'))
    paks=dst/'paks';paks.mkdir(exist_ok=True)
    if config:
        # Existing release is backed up by car_stability before replacing exact pack files.
        for old in [paks/(pak+'.rpak'),paks/(pak+'.starpak')]:
            if old.exists():old.unlink()
        if config.get('unifiedPak'):
            name=config['unifiedPak'];shutil.copy2(project/'texture_project/repak/build'/(name+'.rpak'),paks)
            for oldname in [config['residentPak'],config['materialPak']]:
                old=paks/(oldname+'.rpak')
                if old.exists():old.unlink()
            loading={'Postload':{name+'.rpak':'common.rpak'}}
        else:
            for name in [config['residentPak'],config['materialPak']]:shutil.copy2(project/'texture_project/repak/build'/(name+'.rpak'),paks)
            loading={'Preload':{config['residentPak']+'.rpak':True},'Postload':{config['materialPak']+'.rpak':'common.rpak'}}
        (paks/'rpak.json').write_text(json.dumps(loading,indent=2))
        report['stability']=config
    else:
        for ext in ['rpak','starpak']:shutil.copy2(project/'texture_project/repak/build'/(pak+'.'+ext),paks)
        (paks/'rpak.json').write_text(json.dumps({'Postload':{pak+'.rpak':'common.rpak'}},indent=2))
    mapname=(config.get('unifiedPak') or config['materialPak']) if config else pak
    mapfile=(config.get('unifiedMap') or mapname)+'.json' if config else mapname+'.json'
    mapdata=json.loads((project/'texture_project/repak/maps'/mapfile).read_text())
    asset_type=lambda a:a.get('$type',a.get('_type'))
    asset_path=lambda a:a.get('path',a.get('_path','')).removesuffix('.rpak')
    mat=[a for a in mapdata['files'] if asset_type(a)=='matl']
    legacy=all('$type' in a for a in mapdata['files'])
    if legacy:assert all(a.get('visibilityflags')=='opaque' for a in mat)
    if config and config.get('unifiedPak'):
        textures={asset_path(a) for a in mapdata['files'] if asset_type(a)=='txtr'}
        if legacy:
         references={t for a in mat for t in a.get('textures',[]) if t}
        else:
         references=set()
         assets=project/'texture_project/repak/assets'
         for a in mat:
          material_file=assets/Path(a['_path']).with_suffix('.json')
          material_data=json.loads(material_file.read_text())
          references.update(v.removesuffix('.rpak') for v in material_data.get('$textures',{}).values() if v)
        missing=references-textures
        assert not missing,('Material refers to a texture outside the unified pack',missing)
        assert all(a.get('disableStreaming',a.get('$disableStreaming')) is True for a in mapdata['files'] if asset_type(a)=='txtr')
        from work.car_stability import align_segments
        assert not align_segments(paks/(config['unifiedPak']+'.rpak'),False)
        report['unifiedTextureCount']=len(textures)
    report['publishedPakHashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paks.glob('*.rpak')}
    report['opaqueMaterials']=len(mat)
    meta=json.loads((dst/'mod.json').read_text());meta.update(Version=VERSION,LoadPriority=0)
    if mythic and config and config.get('pcfWeaponGlow'):
        fx_script=json.loads((project/'fx_assets/mod.json.fragment').read_text())
        scripts=[s for s in meta.get('Scripts',[]) if s.get('Path') != fx_script['Path']]
        scripts.append(fx_script);meta['Scripts']=scripts
    (dst/'mod.json').write_text(json.dumps(meta,indent=2))
    kv=dst/'keyvalues/scripts/weapons/mp_weapon_car.txt';kv.parent.mkdir(parents=True,exist_ok=True);kv.write_text('WeaponData\n{\n Mods\n {\n iron_sights { "viewmodel_offset_ads" "0 0 0.65" }\n }\n}\n' if static else PATCH)
    assert not re.search('bodygroup[0-9]_set',PATCH)
    title='CAR 神话皮' if mythic else 'CAR 外域毁灭者'
    readme=f'{title} {VERSION}\n\n计数器仅作为进化开关：不装备=基础；装备=进化动态效果，不显示计数器模型和 ui8 数字。\n模型使用原生 proscreen 名称与 bodygroup5_set 绑定，恢复原版 bodygroup 数值布局；瞄具和弹匣独立控制。\nLoadPriority=0；ADS 保留 0 0 0.65；RPak 在 common.rpak 后加载。\n默认瞄具的 RUI 保留，计数器 RUI 数据仅为兼容而保留、不启用显示。\n'
    if mythic:readme+='换色：死棋金 skin1=rt01；Crimson Fury skin6=rt02；Halloween skin8=rt03。\n'
    if mythic and (project/'native-reload-integration.json').exists():
        report['nativeReload']=json.loads((project/'native-reload-integration.json').read_text())
        readme+='已移植Apex神话皮8组换弹动作，衔接12组中途续换弹；保留原版事件帧和换弹数值，首尾过渡到原生姿势。已核对SMD蒙皮预览，手部贴合仍待用户实机确认。\n'
    if mythic and (project/'audio').is_dir():
        shutil.copytree(project/'audio',dst/'audio',dirs_exist_ok=True)
        report['nativeAudio']=json.loads((project/'native-audio-audit.json').read_text())
        readme+='接入Apex换弹与射击音效，包含SecondShot事件替换；按TF2事件裁切混音，未完整移植Miles事件图。音频为48000Hz/16位PCM。\n'
    if mythic and config and config.get('legacyGlowOverlay'):
        shutil.copytree(project/'glow_assets/mod',dst/'mod',dirs_exist_ok=True)
        report['stableGlow']=json.loads((project/'stable-glow-audit.json').read_text())
        readme+='已删除自定义检视和装饰骨骼动态；装饰绑定枪身。进化状态增加独立UnlitTwoTexture发光叠层及亮度呼吸代理，沿用CNS144样本的材质机制，尚未实机验证。\n'
    if mythic and config and config.get('pcfWeaponGlow'):
        shutil.copytree(project/'fx_assets/mod',dst/'mod',dirs_exist_ok=True)
        report['pcfWeaponGlow']=json.loads((project/'pcf-glow-audit.json').read_text())
        readme+='补回Apex原模型的 VFX_eye、VFX_base、VFX_Bifrost 挂点；动态眼部与核心光效由独立PCF驱动，VMT/VTF继续负责枪身发光叠层。客户端脚本只监听CAR切换，不覆盖武器数值。\n'
    if mythic and (project/'world-emission-audit.json').exists():
        report['worldEmission']=json.loads((project/'world-emission-audit.json').read_text())
        readme+='眼睛网格保留，第三人称进化材质改用支持发光的模板；Apex粒子命名和挂点已核对，实际效果以TF2兼容PCF重建。\n'
    if 'inspect' in report:readme+='新增原创侧倾检视：站立/蹲下待机约5秒后展示枪身，12秒一轮；ADS混合到零检视位移。沿用原生动作切换，打断行为尚未实机验证。修正常驻autoplay层重复叠加进化动画。\n参考CNS144的R301神话皮待机检视方式，未复制其模型和动画。\n'
    if static:readme=f'{title} {VERSION}\n恢复原版计数器外壳和数字；移除全部进化旋转层、光环与进化材质。保留默认瞄具、ADS 0 0 0.65、LoadPriority=0。\n颜色图RGB不变、alpha固定255；光泽乘0.60，高光乘0.45。DDS编码：nml=BC5_UNORM，gls=BC4_UNORM，col/spc=BC7_UNORM_SRGB，其余数据图保持线性。\n'
    if static and config and config.get('repakVersion'):readme+=f"使用官方 RePak {config['repakVersion']} 新格式重新构建统一 RPAK。\n"
    if config:readme+=('贴图和材质合并到同一RPak，使用RePak1.2的disableStreaming常驻贴图，直接在common.rpak后加载；移除跨包纹理依赖与预载。\n' if config.get('unifiedPak') else '贴图预载，材质在common.rpak后加载。\n')
    readme+='已做编译和静态结构核对，未启动游戏测试。\n'
    if not static:readme+='动态效果为 TF2 重建，不是 Apex 原生粒子和检视动画的完整移植。\n'
    if config:readme+='已修正旧版RePak材质内存段未计入页对齐填充的问题，并用RSX重新读取确认。\n'
    readme+='安装：用本文件夹替换旧的同名模组文件夹，不要合并遗留旧RPak；只启用一套 CAR 替换模组。\n'
    (RELEASE/(folder+'-说明.txt')).write_text(readme,encoding='utf8')
    report['references']=['https://docs.northstar.tf/Modding/guides/tools/MDLModding/','https://docs.northstar.tf/Modding/guides/keyvalue/weaponkeyvalues/','https://docs.northstar.tf/Modding/guides/tools/rpakmodding/','R2Vanilla/runtime/compiled/scripts/weapons/mod_original_mp_weapon_car.txt','work/car_pipeline/README.md']
    (RELEASE/(folder+'-audit.json')).write_text(json.dumps(report,indent=2))
    archive=RELEASE/(folder+'-'+VERSION+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in dst.rglob('*'):
            if p.is_file():z.write(p,p.relative_to(RELEASE))
    expected=sum(1 for p in dst.rglob('*') if p.is_file())
    with zipfile.ZipFile(archive) as z:assert len(z.namelist())==expected and z.testzip() is None
    print('EVOLUTION_RELEASE_READY',archive,flush=True)
