"""Build isolated mythic core, eye and wing autoplay layers.

The gun body remains rigid on def_c_base.  Only meshes using the eye and
feather material families are rebound, so ordinary CAR weapon animations do
not move the mythic decoration roots.
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parent
VIEW = ROOT / "source" / "view"
WORLD = ROOT / "source" / "world"
BEGIN = "// CODEX_INDEPENDENT_MYTHIC_ANIMATION_BEGIN"
END = "// CODEX_INDEPENDENT_MYTHIC_ANIMATION_END"


def smd_nodes(lines: list[str]) -> dict[int, str]:
    start = lines.index("nodes")
    end = lines.index("end", start)
    result = {}
    for line in lines[start + 1 : end]:
        index, rest = line.split(" ", 1)
        result[int(index)] = rest.split('"')[1]
    return result


def restore_original_bindings(path: Path, original: Path) -> dict:
    lines = path.read_text(encoding="utf-8").splitlines()
    old_lines = original.read_text(encoding="utf-8").splitlines()
    nodes = smd_nodes(lines)
    if nodes != smd_nodes(old_lines):
        raise RuntimeError(f"{path}: source skeleton differs from original Apex rig")
    def geometry_key(vertices: list[list[str]], overlay: bool = False) -> tuple:
        result = []
        for vertex in vertices:
            values = list(map(float, vertex[1:9]))
            if overlay:
                values[0:3] = [values[index] - values[index + 3] * 0.015 for index in range(3)]
            result.append(tuple(values))
        return tuple(result)

    def same_geometry(left: tuple, right: tuple) -> bool:
        return all(abs(a - b) < 0.000001 for lv, rv in zip(left, right) for a, b in zip(lv, rv))

    old_tri = old_lines.index("triangles") + 1
    original_triangles = []
    while old_lines[old_tri] != "end":
        vertices = [old_lines[old_tri + offset].split() for offset in range(1, 4)]
        key = geometry_key(vertices)
        weights = [(vertex[0], vertex[9:]) for vertex in vertices]
        original_triangles.append((key, weights))
        old_tri += 4
    tri = lines.index("triangles")
    out = lines[: tri + 1]
    cursor = tri + 1
    counts: dict[str, int] = {}
    triangle_index = 0
    overlay_source_index = 0
    while lines[cursor] != "end":
        material = lines[cursor]
        out.append(material)
        cursor += 1
        vertices = [lines[cursor + offset].split() for offset in range(3)]
        geometry = geometry_key(vertices)
        if triangle_index < len(original_triangles) and same_geometry(geometry, original_triangles[triangle_index][0]):
            weights = original_triangles[triangle_index][1]
        else:
            overlay_geometry = geometry_key(vertices, overlay=True)
            weights = None
            while overlay_source_index < len(original_triangles):
                candidate_geometry, candidate_weights = original_triangles[overlay_source_index]
                overlay_source_index += 1
                if same_geometry(overlay_geometry, candidate_geometry):
                    weights = candidate_weights
                    break
        if weights is None:
            raise RuntimeError(f"{path}: cannot recover Apex weights for triangle {triangle_index}")
        for fields, (primary, tail) in zip(vertices, weights):
            out.append(" ".join([primary, *fields[1:9], *tail]))
            bone_name = nodes[int(primary)]
            counts[bone_name] = counts.get(bone_name, 0) + 1
        cursor += 3
        triangle_index += 1
    path.write_text("\n".join(out + ["end"]) + "\n", encoding="utf-8")
    counts = {
        "file": str(path),
        "vertices": sum(counts.values()),
        "animatedBonesUsed": len(counts),
        "topPrimaryBindings": sorted(counts.items(), key=lambda item: item[1], reverse=True)[:16],
        "source": str(original),
    }
    return counts


def split_motion(source: Path, selections: dict[str, set[str]]) -> dict[str, Path]:
    lines = source.read_text(encoding="utf-8").splitlines()
    nodes = smd_nodes(lines)
    ids = {name: index for index, name in nodes.items()}
    skeleton = lines.index("skeleton")
    end = lines.index("end", skeleton)
    prefix = lines[: skeleton + 1]
    outputs = {}
    for stem, names in selections.items():
        wanted = {ids[name] for name in names}
        body = []
        for line in lines[skeleton + 1 : end]:
            if line.startswith("time "):
                body.append(line)
            elif int(line.split()[0]) in wanted:
                body.append(line)
        destination = source.with_name(stem + ".smd")
        destination.write_text("\n".join(prefix + body + ["end"]) + "\n", encoding="utf-8")
        outputs[stem] = destination
    return outputs


def weightlist(name: str, bones: list[str], active: set[str]) -> str:
    rows = [f'$weightlist "{name}" {{']
    rows.extend(f' "{bone}" {1 if bone in active else 0}' for bone in bones)
    rows.append("}")
    return "\n".join(rows)


def append_layers(qc: Path, motion: Path, view: bool) -> list[str]:
    text = qc.read_text(encoding="utf-8")
    if BEGIN in text:
        text = text[: text.index(BEGIN)] + text[text.index(END) + len(END) :]
    nodes = list(smd_nodes(motion.read_text(encoding="utf-8").splitlines()).values())
    layers = [
        ("mythic_motion", "mythic_core_motion", "mythic_core_only", {"def_core_orb"}),
    ]
    if view:
        layers += [
            ("mythic_eye_motion", "mythic_eye_motion", "mythic_eye_only", {"def_eye_body"}),
            (
                "mythic_wing_motion",
                "mythic_wing_motion",
                "mythic_wings_only",
                {"def_wing_upper_arm_l_1", "def_wing_upper_arm_r_1"},
            ),
        ]
    block = [BEGIN]
    for sequence, smd, weights, active in layers:
        block.append(weightlist(weights, nodes, active))
        block.append(
            f'$sequence "{sequence}" {{ "{smd}.smd" fps 30 loop delta autoplay weightlist "{weights}" }}'
        )
    block.append(END)
    qc.write_text(text.rstrip() + "\n\n" + "\n".join(block) + "\n", encoding="utf-8")
    return [item[0] for item in layers]


def main() -> None:
    backup = ROOT / "backups" / "before-full-independent-animation-1.1.1"
    if not backup.exists():
        shutil.copytree(ROOT / "source", backup / "source")
    original = ROOT / "backups" / "before-stable-glow-1.0.8" / "source" / "view"
    geometry = [
        restore_original_bindings(VIEW / "mythic_base.smd", original / "mythic_base.smd"),
        restore_original_bindings(VIEW / "mythic_evolved.smd", original / "mythic_evolved.smd"),
    ]
    split_motion(
        VIEW / "mythic_motion.smd",
        {
            "mythic_core_motion": {"def_core_orb"},
            "mythic_eye_motion": {"def_eye_body"},
            "mythic_wing_motion": {"def_wing_upper_arm_l_1", "def_wing_upper_arm_r_1"},
        },
    )
    split_motion(WORLD / "mythic_motion.smd", {"mythic_core_motion": {"def_core_orb"}})
    view_layers = append_layers(VIEW / "ptpov_car101.qc", VIEW / "mythic_motion.smd", True)
    world_layers = append_layers(WORLD / "w_car_richmahogany.qc", WORLD / "mythic_motion.smd", False)
    report = {
        "version": "1.1.1",
        "gameTested": False,
        "bodyAnimated": False,
        "viewLayers": view_layers,
        "worldLayers": world_layers,
        "geometryBindings": geometry,
        "coreCycleDegrees": 360,
        "wingRootAmplitudeRadians": 0.069771,
        "eyeAmplitudeRadians": 0.017443,
    }
    (ROOT / "independent-animation-audit.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
