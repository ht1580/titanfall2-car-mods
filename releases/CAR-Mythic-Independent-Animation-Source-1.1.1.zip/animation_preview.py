import bpy
from pathlib import Path
B=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(B/'preview.blend'));scene=bpy.context.scene;bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(B/'preview.blend'))
frames=B/'animation_frames';frames.mkdir(exist_ok=True);scene.render.resolution_x=840;scene.render.resolution_y=480
for frame in range(0,90,6):
 scene.frame_set(frame);scene.render.filepath=str(frames/f'{frame:03d}.png');bpy.ops.render.render(write_still=True)
print('ANIMATION_PREVIEW_READY')
