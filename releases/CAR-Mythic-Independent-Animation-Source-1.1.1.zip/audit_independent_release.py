from __future__ import annotations

import hashlib
import json
import re
import struct
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RELEASE = Path(r"D:\TitanfallMods\CAR.Mythic.Allfather-1.1.1.zip")
PREVIOUS = Path(r"D:\TitanfallMods\CAR.Mythic.Allfather-1.0.10.zip")


def cstr(data: bytes, offset: int) -> str:
    return data[offset : data.index(0, offset)].decode("utf-8", "replace")


def mdl_sequences(data: bytes) -> list[dict]:
    count, offset = struct.unpack_from("<2i", data, 192)
    result = []
    for index in range(count):
        base = offset + index * 232
        label = cstr(data, base + struct.unpack_from("<i", data, base + 4)[0])
        flags = struct.unpack_from("<i", data, base + 12)[0]
        layer_count, layer_offset = struct.unpack_from("<2i", data, base + 148)
        layers = [struct.unpack_from("<h", data, base + layer_offset + i * 24)[0] for i in range(layer_count)]
        result.append({"index": index, "label": label, "flags": flags, "layers": layers})
    return result


def source_vertex_bindings(path: Path) -> dict[str, int]:
    lines = path.read_text(encoding="utf-8").splitlines()
    start, end = lines.index("nodes"), lines.index("end", lines.index("nodes"))
    names = {int(row.split(" ", 1)[0]): row.split('"')[1] for row in lines[start + 1 : end]}
    tri = lines.index("triangles") + 1
    counts: dict[str, int] = {}
    while lines[tri] != "end":
        for row in lines[tri + 1 : tri + 4]:
            bone = names[int(row.split()[0])]
            counts[bone] = counts.get(bone, 0) + 1
        tri += 4
    return counts


def zip_hashes(path: Path) -> dict[str, str]:
    with zipfile.ZipFile(path) as archive:
        return {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if not name.endswith("/")}


def find_model(files: dict[str, str], name: str) -> str:
    return next(path for path in files if path.replace("\\", "/").endswith("/" + name))


new_hashes = zip_hashes(RELEASE)
old_hashes = zip_hashes(PREVIOUS)
ignored_suffixes = (
    "/ptpov_car101.mdl",
    "/w_car101.mdl",
    "/mod.json",
    "/README.txt",
    "/CAR.Mythic.Allfather-audit.json",
)
unchanged_candidates = {
    path for path in new_hashes.keys() & old_hashes.keys() if not path.replace("\\", "/").endswith(ignored_suffixes)
}
changed_non_model = sorted(path for path in unchanged_candidates if new_hashes[path] != old_hashes[path])

with zipfile.ZipFile(RELEASE) as archive:
    view_data = archive.read(find_model(new_hashes, "ptpov_car101.mdl"))
    world_data = archive.read(find_model(new_hashes, "w_car101.mdl"))

view_sequences = mdl_sequences(view_data)
world_sequences = mdl_sequences(world_data)
view_labels = {item["label"] for item in view_sequences}
world_labels = {item["label"] for item in world_sequences}
independent = {"mythic_motion", "mythic_eye_motion", "mythic_wing_motion"}
view_indices = {item["index"] for item in view_sequences if item["label"] in independent}
world_indices = {item["index"] for item in world_sequences if item["label"] in independent}
ordinary_view_edges = sum(bool(set(item["layers"]) & view_indices) for item in view_sequences if item["index"] not in view_indices)
ordinary_world_edges = sum(bool(set(item["layers"]) & world_indices) for item in world_sequences if item["index"] not in world_indices)

view_qc = (ROOT / "source/view/ptpov_car101.qc").read_text(encoding="utf-8")
world_qc = (ROOT / "source/world/w_car_richmahogany.qc").read_text(encoding="utf-8")
report = {
    "version": "1.1.1",
    "gameTested": False,
    "release": str(RELEASE),
    "sha256": hashlib.sha256(RELEASE.read_bytes()).hexdigest(),
    "compiledSequences": {
        "viewCount": len(view_sequences),
        "viewIndependent": sorted(view_labels & independent),
        "worldCount": len(world_sequences),
        "worldIndependent": sorted(world_labels & independent),
        "ordinaryViewReferencesToIndependent": ordinary_view_edges,
        "ordinaryWorldReferencesToIndependent": ordinary_world_edges,
        "viewIndependentFlags": {item["label"]: item["flags"] for item in view_sequences if item["label"] in independent},
        "worldIndependentFlags": {item["label"]: item["flags"] for item in world_sequences if item["label"] in independent},
    },
    "sourceBindings": {
        "base": source_vertex_bindings(ROOT / "source/view/mythic_base.smd"),
        "evolved": source_vertex_bindings(ROOT / "source/view/mythic_evolved.smd"),
    },
    "qc": {
        "viewAutoplayDeltaLayers": sorted(re.findall(r'\$sequence\s+"(mythic[^\"]+)"[^\n]*\bdelta\s+autoplay\b', view_qc)),
        "worldAutoplayDeltaLayers": sorted(re.findall(r'\$sequence\s+"(mythic[^\"]+)"[^\n]*\bdelta\s+autoplay\b', world_qc)),
        "viewMuzzleTowardGun": bool(re.search(r'\$attachment\s+"muzzle_flash"[^\n]*\b0\s+0\.65\s+0\b', view_qc)),
        "worldMuzzleTowardGun": bool(re.search(r'\$attachment\s+"muzzle_flash"[^\n]*\b0\s+0\.65\s+0\b', world_qc)),
    },
    "unchangedFrom1010": {
        "comparedFiles": len(unchanged_candidates),
        "changedUnexpectedFiles": changed_non_model,
    },
}

required_body = "def_c_base"
print(json.dumps(report, ensure_ascii=False, indent=2))
for name, bindings in report["sourceBindings"].items():
    assert required_body in bindings
    assert any(bone.startswith("def_eye") or bone in {"def_iris", "def_upper_lid", "def_lower_lid"} for bone in bindings)
    assert any(bone.startswith("def_wing_upper_l_") for bone in bindings)
    assert any(bone.startswith("def_wing_upper_r_") for bone in bindings)
assert len(report["sourceBindings"]["base"]) >= 40
assert len(report["sourceBindings"]["evolved"]) >= 100
assert report["compiledSequences"]["viewIndependent"] == sorted(independent)
assert report["compiledSequences"]["worldIndependent"] == ["mythic_motion"]
assert all(flags & 0x000C == 0x000C for flags in report["compiledSequences"]["viewIndependentFlags"].values())
assert all(flags & 0x000C == 0x000C for flags in report["compiledSequences"]["worldIndependentFlags"].values())
assert ordinary_view_edges == ordinary_world_edges == 0
assert report["qc"]["viewAutoplayDeltaLayers"] == sorted(independent)
assert report["qc"]["worldAutoplayDeltaLayers"] == ["mythic_motion"]
assert report["qc"]["viewMuzzleTowardGun"] and report["qc"]["worldMuzzleTowardGun"]
assert not changed_non_model, changed_non_model

destination = ROOT / "independent-release-audit.json"
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
