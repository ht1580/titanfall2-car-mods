"""Preview the real retargeted meshes with an animated Blender armature."""
import bpy,re,math,json
from pathlib import Path
from mathutils import Matrix,Vector,Euler,Quaternion
B=Path(__file__).resolve().parent;V=B/'source/view';T=B/'texture_project/.workbench_textures'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
lines=(V/'mythic_evolved.smd').read_text().splitlines();a=lines.index('nodes')+1;e=lines.index('end',a);nodes={}
for row in lines[a:e]:
 m=re.match(r'\s*(\d+) "([^"]+)" (-?\d+)',row);nodes[int(m[1])]=(m[2],int(m[3]))
a=lines.index('skeleton')+1;e=lines.index('end',a);loc={};glob={}
for row in lines[a:e]:
 t=row.split()
 if t[0]=='time':continue
 loc[int(t[0])]=Matrix.Translation(Vector(tuple(map(float,t[1:4]))))@Euler(tuple(map(float,t[4:7])),'XYZ').to_matrix().to_4x4()
def g(i):
 if i not in glob:glob[i]=(g(nodes[i][1]) if nodes[i][1]>=0 else Matrix.Identity(4))@loc[i]
 return glob[i]
for i in nodes:g(i)
data=bpy.data.armatures.new('TF2_stock_and_mythic_helpers');rig=bpy.data.objects.new('CAR_Rig',data);bpy.context.collection.objects.link(rig);bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
for i,(name,parent) in nodes.items():
 bone=data.edit_bones.new(name);bone.matrix=glob[i];bone.length=.2
 if parent>=0:bone.parent=data.edit_bones[nodes[parent][0]]
bpy.ops.object.mode_set(mode='OBJECT');rig.show_in_front=True
cache={}
def material(category,stage,color):
 key=(category,stage,color)
 if key in cache:return cache[key]
 m=bpy.data.materials.new('_'.join(key));m.use_nodes=True;nt=m.node_tree;s=nt.nodes.get('Principled BSDF');s.inputs['Metallic'].default_value=.3;s.inputs['Roughness'].default_value=.45
 col=T/f'{category}_{color}_col.png'
 if col.exists():
  tex=nt.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(col),check_existing=True);nt.links.new(tex.outputs['Color'],s.inputs['Base Color'])
 ilm=B/f'{category}_{color}_ilm.png'
 if stage=='evolved' and ilm.exists():
  tex=nt.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(ilm),check_existing=True);nt.links.new(tex.outputs['Color'],s.inputs['Emission Color']);s.inputs['Emission Strength'].default_value=2
 cache[key]=m;return m
objects={}
def mesh(path,name,stage):
 l=path.read_text().splitlines();i=l.index('triangles')+1;verts=[];normals=[];uv=[];faces=[];cats=[];weights={}
 while l[i].strip()!='end':
  mat=l[i].lower().replace('/','\\');cat='eye' if 'eye' in mat else ('feather' if 'feather' in mat else 'main');cats.append(cat);faces.append(tuple(range(len(verts),len(verts)+3)))
  for row in l[i+1:i+4]:
   t=row.split();index=len(verts);verts.append(tuple(map(float,t[1:4])));normals.append(tuple(map(float,t[4:7])));uv.append(tuple(map(float,t[7:9])))
   links=[(int(t[10+2*j]),float(t[11+2*j])) for j in range(int(t[9]))] if len(t)>9 else [(int(t[0]),1)]
   for bone,w in links:weights.setdefault((bone,round(w,8)),[]).append(index)
  i+=4
 m=bpy.data.meshes.new(name);m.from_pydata(verts,[],faces);m.update();ob=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(ob);u=m.uv_layers.new()
 for loop in m.loops:u.data[loop.index].uv=uv[loop.vertex_index]
 if hasattr(m,'normals_split_custom_set'):m.normals_split_custom_set(normals)
 for cat in ['eye','feather','main']:m.materials.append(material(cat,stage,'default'))
 for face,cat in zip(m.polygons,cats):face.material_index=['eye','feather','main'].index(cat);face.use_smooth=True
 groups={}
 for (bone,w),indices in weights.items():
  # Stock counter meshes retain their own indices; previews only use converted meshes.
  if bone not in groups:groups[bone]=ob.vertex_groups.new(name=nodes[bone][0])
  groups[bone].add(indices,w,'REPLACE')
 modifier=ob.modifiers.new('Retargeted CAR rig','ARMATURE');modifier.object=rig;objects[name]=(ob,stage);return ob,verts
evolved,verts=mesh(V/'mythic_evolved.smd','Counter_ON_evolved','evolved');base,_=mesh(V/'mythic_base.smd','Counter_OFF_base','base');mesh(V/'v_car101_magazine.smd','Magazine','base');mesh(V/'v_car101_sight_on.smd','Iron_front','base');base.hide_render=True
motion=['def_core_orb','def_eye_body','def_wing_upper_arm_l_1','def_wing_upper_arm_r_1']
for frame in range(91):
 for name in motion:
  if name not in rig.pose.bones:continue
  p=rig.pose.bones[name];p.rotation_mode='XYZ';angle=(math.tau*frame/90 if name=='def_core_orb' else math.radians(1 if name=='def_eye_body' else 4)*math.sin(math.tau*frame/90)*(1 if '_l_' in name else -1));p.rotation_euler=(0,0,angle);p.keyframe_insert('rotation_euler',frame=frame)
scene=bpy.context.scene;scene.frame_start=0;scene.frame_end=90;scene.render.fps=30;scene.frame_set(0);scene.render.engine='BLENDER_EEVEE';scene.render.resolution_x=1400;scene.render.resolution_y=800;scene.render.resolution_percentage=100
center=sum((Vector(v) for v in verts),Vector())/len(verts);size=max(max(v[j] for v in verts)-min(v[j] for v in verts) for j in range(3));bpy.ops.object.camera_add(location=center+Vector((size*1.1,size*.5,size*.2)));cam=bpy.context.object;cam.rotation_mode='QUATERNION';cam.rotation_quaternion=(center-cam.location).to_track_quat('-Z','Y')@Quaternion((0,0,1),math.pi/2);cam.data.type='ORTHO';cam.data.ortho_scale=size*1.45;scene.camera=cam
for offset in [(size,size,size),(-size,size,-size)]:
 bpy.ops.object.light_add(type='AREA',location=center+Vector(offset));light=bpy.context.object;light.data.energy=120000;light.data.size=size;light.rotation_euler=(center-light.location).to_track_quat('-Z','Y').to_euler()
scene.world.color=(.1,.1,.1)
for stage,color in [('base','default'),('evolved','default'),('evolved','rt01'),('evolved','rt02'),('evolved','rt03')]:
 base.hide_render=stage!='base';evolved.hide_render=stage!='evolved'
 for ob,obstage in objects.values():
  for i,cat in enumerate(['eye','feather','main']):ob.data.materials[i]=material(cat,obstage,color)
 scene.render.filepath=str(B/f'preview-{stage}-{color}.png');bpy.ops.render.render(write_still=True)
base.hide_render=True;evolved.hide_render=False
for ob,obstage in objects.values():
 for i,cat in enumerate(['eye','feather','main']):ob.data.materials[i]=material(cat,obstage,'default')
scene['Counter_selection']='Counter_OFF_base / Counter_ON_evolved';bpy.ops.wm.save_as_mainfile(filepath=str(B/'preview.blend'));print('MYTHIC_PREVIEWS_READY')
